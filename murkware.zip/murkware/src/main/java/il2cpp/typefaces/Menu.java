package il2cpp.typefaces;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.inputmethod.InputMethodManager;
import il2cpp.*;
import android.text.*;
import android.view.Window.*; 
import android.text.method.*;
import android.graphics.Typeface;
import android.util.*;
import android.view.*;
import android.widget.*;
import android.view.animation.AlphaAnimation; 
import android.view.animation.Animation;
import java.io.*;
import java.util.Objects;
import android.widget.LinearLayout.LayoutParams;
import java.util.ArrayList;
import android.view.View.OnClickListener;
import il2cpp.typefaces.*;

public class Menu
{
	protected int WIDTH,HEIGHT;
    
	public Typeface google(Context yes) {return Typeface.createFromAsset(yes.getAssets(), "Font.ttf");}
	
	protected Context context;
	protected FrameLayout parentBox;
	protected LinearLayout page;
	protected ScrollView scroll;
	
	public ArrayList<PageButton> _pagebuttons = new ArrayList<>();
	public ArrayList<LinearLayout> pages = new ArrayList<>();
	
	public ImageView icon;
	
	boolean isShow = false;
	
	LinearLayout menulayout,linear9,linear14,pgs,close,leaner,linear25,scrl;
	TextView textview18,textview20,title;
 ImageView imageview17;
	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;
	
	protected void init(Context context) {
		
		this.context = context;
		
		parentBox = new FrameLayout(context);

		parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0,//initialX
			0,//initialy
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.CENTER;
	}
	
	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public void showMenu() {
		isShow = true;
		parentBox.removeAllViews();
		parentBox.addView(menulayout);
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 0f, 1.0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f));															 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f);
		scaleDown.setDuration(350);
		scaleDown.start();
	}

	public void hideMenu() {
		isShow = false;
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0f));
		scaleDown.setDuration(350);
		scaleDown.start();
		new Handler().postDelayed(new Runnable() {
			public void run() {
				parentBox.removeAllViews();
				parentBox.addView(icon, dpi(50), dpi(50));
				Utils.anim(icon, 200);
			}
		}, 350);
	}
	
	public void newPage(String nm) {
		LinearLayout _page = new LinearLayout(context);
		PageButton _butt = new PageButton(context, nm);
		final int pageid = pages.size();
		page.setOrientation(LinearLayout.VERTICAL);
		_page.setOrientation(LinearLayout.VERTICAL);
		page.addView(_page, -1, -1);
		_page.setVisibility(View.GONE);
		pages.add(_page);
		_butt.callback = new PageButton.Callback() {
			public void onClick() {
				showPage(pageid);
			}
		};
		
		pgs.addView(_butt);
	}
	
	public void showPage(final int id) {
		for (LinearLayout layout: pages) {
			layout.setVisibility(View.GONE);
		}
		pages.get(id).setVisibility(View.VISIBLE);
		Utils.anim(pages.get(id), 400);
	}
	
	public Menu(Context context)
	{
		init(context);
		
		icon = new ImageView(context);
		Utils.SetAssets(context, icon, "icon.png");
		
				menulayout = new LinearLayout(context);
				{
					menulayout.setOrientation(0);
					menulayout.setPadding(5, 5, 5, 5);
					menulayout.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					menulayout.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(875, 595, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					menulayout.setLayoutParams(lp);
				}

		linear9 = new LinearLayout(context);
				{
					linear9.setOrientation(1);
					linear9.setPadding(5, 5, 5, 5);
					linear9.setGravity(0);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-15400895);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, -16777216);
					linear9.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(234, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					linear9.setLayoutParams(lp);
				}
menulayout.addView(linear9);

		linear14 = new LinearLayout(context);
				{
					linear14.setOrientation(1);
					linear14.setPadding(5, 5, 5, 5);
					linear14.setGravity(49);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-15400895);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					linear14.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, 210, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					linear14.setLayoutParams(lp);
				}
linear9.addView(linear14);

		imageview17 = new ImageView(context);
				{
					imageview17.setPadding(5, 5, 5, 5);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16776961);
					imageview17.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(157, 157, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					imageview17.setLayoutParams(lp);
					
					Utils.SetAssets(context, imageview17, "icon.png");
				}
linear14.addView(imageview17);

		textview18 = new TextView(context);
				{
					textview18.setText("DarkWare");
					textview18.setPadding(5, 5, 5, 5);
					textview18.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, 0);
					textview18.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-2, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					textview18.setLayoutParams(lp);
					textview18.setTextColor(-1);
					textview18.setTextSize(13.0f);
					textview18.setTypeface(google(context));
				}
linear14.addView(textview18);

		pgs = new LinearLayout(context);
				{
					pgs.setOrientation(1);
					pgs.setPadding(5, 5, 5, 5);
					pgs.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-15400895);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -1);
					pgs.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(224, 304, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					pgs.setLayoutParams(lp);
				}
linear9.addView(pgs);

		close = new LinearLayout(context);
				{
					close.setOrientation(1);
					close.setPadding(5, 5, 5, 5);
					close.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -16777216);
					close.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 15;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					close.setLayoutParams(lp);
				}
linear9.addView(close);

		textview20 = new TextView(context);
				{
					textview20.setText("close menu");
					textview20.setPadding(5, 5, 5, 5);
					textview20.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, 0);
					textview20.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-2, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					textview20.setLayoutParams(lp);
					textview20.setTextColor(-1);
					textview20.setTextSize(13.0f);
					textview20.setTypeface(google(context));
				}
close.addView(textview20);

		leaner = new LinearLayout(context);
				{
					leaner.setOrientation(1);
					leaner.setPadding(5, 5, 5, 5);
					leaner.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-15400895);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -13828346);
					leaner.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -1, 0);
					lp.leftMargin   = 34;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					leaner.setLayoutParams(lp);
				}
menulayout.addView(leaner);

		linear25 = new LinearLayout(context);
				{
					linear25.setOrientation(0);
					linear25.setPadding(5, 5, 5, 5);
					linear25.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(-7194375);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -1);
					linear25.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					linear25.setLayoutParams(lp);
				}
leaner.addView(linear25);

		title = new TextView(context);
				{
					title.setText("Page Name");
					title.setPadding(5, 5, 5, 5);
					title.setGravity(17);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(1, 0);
					title.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-2, -2, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					title.setLayoutParams(lp);
					title.setTextColor(-1);
					title.setTextSize(15.0f);
					title.setTypeface(google(context));
				}
linear25.addView(title);

		scrl = new LinearLayout(context);
				{
					scrl.setOrientation(1);
					scrl.setPadding(5, 5, 5, 5);
					scrl.setGravity(51);
					
					GradientDrawable design = new GradientDrawable();
					design.setColor(0);
					design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
					design.setStroke(0, -11862054);
					scrl.setBackgroundDrawable(design);
					
					LayoutParams lp = new LayoutParams(-1, -1, 0);
					lp.leftMargin   = 0;
					lp.topMargin    = 0;
					lp.rightMargin  = 0;
					lp.bottomMargin = 0;
					scrl.setLayoutParams(lp);
				}
leaner.addView(scrl);
		
		close.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				hideMenu();
			}
		});
		
		scroll = new ScrollView(context);
		scroll.setFillViewport(true);
		
		page = new LinearLayout(context);
		page.setOrientation(LinearLayout.VERTICAL);
		
		scroll.addView(page, -1, -1);
		scrl.addView(scroll, -1, -1);
		
		hideMenu();
		wmManager.addView(parentBox, wmParams);
	}
	
	View.OnTouchListener handleMotionTouch = new View.OnTouchListener()
	{
		private float initX;          
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;
		
		@Override
		public boolean onTouch(View vw, MotionEvent ev)
		{

			switch (ev.getAction())
			{
				case MotionEvent.ACTION_DOWN:

					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;

				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);

					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);


					wmManager.updateViewLayout(vw, wmParams);
					break;

				case MotionEvent.ACTION_UP:
					if (!isShow && (System.currentTimeMillis() < (clock + 200)))
					{
						showMenu();
					}
					break;
			}
			return true;
		}
	};
}
